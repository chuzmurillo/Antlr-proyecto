var app = angular.module('ASMSimulator', []);
